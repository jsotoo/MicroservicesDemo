﻿namespace Net.Microservices.CleanArchitecture.Presentation.Framework
{
    public enum CRUDElementTypeEnum
    {
        View,
        Edit,
        Delete,
        Save,
        Cancel
    }
}
