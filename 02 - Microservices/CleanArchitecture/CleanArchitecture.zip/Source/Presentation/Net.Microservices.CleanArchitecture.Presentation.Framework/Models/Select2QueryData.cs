﻿namespace NEvaldas.Blazor.Select2.Models
{
    public class Select2QueryData
    {
        public int Page { get; set; }
        public int Size { get; set; }
        public string Term { get; set; }
        public string Type { get; set; }
    }
}
