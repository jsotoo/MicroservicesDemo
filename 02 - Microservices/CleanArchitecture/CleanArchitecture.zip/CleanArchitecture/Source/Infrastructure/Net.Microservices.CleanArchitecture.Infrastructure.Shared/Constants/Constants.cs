﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net.Microservices.CleanArchitecture.Infrastructure.Shared
{
    public static class Constants
    {
        public const int MaxPhotoUploadSizeMb = 30;
    }
}
