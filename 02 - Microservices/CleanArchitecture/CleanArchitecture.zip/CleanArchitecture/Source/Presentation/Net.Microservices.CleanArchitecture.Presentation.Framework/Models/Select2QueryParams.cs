﻿namespace NEvaldas.Blazor.Select2.Models
{
    internal class Select2QueryParams
    {
        public string Type { get; set; }

        public Select2QueryData Data { get; set; }
    }
}
