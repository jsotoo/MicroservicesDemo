﻿namespace Net.Microservices.CleanArchitecture.Core.Domain
{
    public enum RolesEnum
    {
        User = 2,
        Admin = 4,
        SuperAdmin = 8
    }
}
