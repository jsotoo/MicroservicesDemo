﻿namespace Net.Microservices.CleanArchitecture.Common
{
    public enum ThemeEnum : byte
    {
        Light = 0,
        Dark = 1
    }
}
