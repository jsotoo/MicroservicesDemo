﻿namespace Net.Microservices.CleanArchitecture.Presentation.Web.ViewModels
{
    public class HomeViewModel
    {
    }
}
