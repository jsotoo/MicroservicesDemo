﻿namespace Net.Microservices.CleanArchitecture.Presentation.Web.ViewModels.Orders
{
    public class CreateOrderViewModel
    {
    }
}
