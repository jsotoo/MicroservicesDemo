﻿using System;

namespace Net.Microservices.CleanArchitecture.Presentation.Web.ViewModels
{
    public class FooterViewModel
    {
        public DateTime Date { get; set; }
        public string Version { get; set; }
    }
}
