﻿using AutoMapper;

namespace Net.Microservices.CleanArchitecture.Infrastructure.Mappings
{
    internal class EventProfile : Profile
    {
        public EventProfile() {
        }
    }
}