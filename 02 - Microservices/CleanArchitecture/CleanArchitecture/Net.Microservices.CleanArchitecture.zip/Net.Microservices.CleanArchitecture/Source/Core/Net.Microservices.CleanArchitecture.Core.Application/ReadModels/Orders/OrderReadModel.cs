﻿namespace Net.Microservices.CleanArchitecture.Core.Application.ReadModels.Orders
{
    public class OrderReadModel
    {
    }
}
