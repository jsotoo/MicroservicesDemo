﻿using Microsoft.AspNetCore.Authorization.Infrastructure;

namespace Net.Microservices.CleanArchitecture.Core.Application.Authorization
{
    public class UserOperationAuthorizationRequirement : OperationAuthorizationRequirement
    {
    }
}
