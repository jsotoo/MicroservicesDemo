﻿namespace Net.Microservices.CleanArchitecture.Common
{
    public class FileStorageOptions
    {
        public string BasePath { get; set; }
    }
}
