﻿namespace Net.Microservices.CleanArchitecture.Common
{
    public enum LanguageEnum
    {
        Greek,
        English
    }
}
